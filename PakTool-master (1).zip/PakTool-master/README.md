# PakTool
Assalam o Alaikum Friends
How Are You

To Use This Tool You Have To Follow The Steps Given Below

Steps.
First You Have To Apply The Following Commands
pkg update
pkg upgrade
pkg install git
pkg install python
pkg install python2
pip2 install requests
pip2 install mechanize
git clone http://github.com/ZahidMahmood786/PakTool
cd PakTool
ls
python2 pak.py

Enjoy.....
Dont Forget To Subscribe My Channel

Youtube: https://www.youtube.com/channel/UC6JohltW-LGhuwWnXH6lOug
